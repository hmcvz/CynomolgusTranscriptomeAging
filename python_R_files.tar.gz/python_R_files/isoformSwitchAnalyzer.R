library(BSgenome.Mfascicularis.NCBI.5.0)
library(IsoformSwitchAnalyzeR)
library(dplyr)
library(patchwork)
packageVersion('IsoformSwitchAnalyzeR')

##########################
##### importing data #####
##########################

kallistoQuant <- importIsoformExpression(parentDir = "./source_data/kallisto/kallisto_analysis/analysis",addIsofomIdAsColumn = TRUE)


#kallistoQuant
#kallistoQuant$abundance
#kallistoQuant$counts

##############################
##### Make design matrix #####
##############################

#head(kallistoQuant$abundance)
#colnames(kallistoQuant$abundance)[-1]
#gsub('_\\w*_\\w*', '', colnames(kallistoQuant$abundance)[-1])

myDesign <- data.frame(sampleID = colnames(kallistoQuant$abundance)[-1],
                       condition = gsub('_\\w*_\\w*', '', colnames(kallistoQuant$abundance)[-1]))

#myDesign



#####################################
##### Create switchanalyzeRlist #####
#####################################

aSwitchList <- importRdata(isoformCountMatrix   = kallistoQuant$counts,
                           isoformRepExpression = kallistoQuant$abundance,
                           designMatrix         = myDesign,
                           isoformExonAnnoation = "./source_data/isoformswitchanalyzer/reference/Macaca_fascicularis.Macaca_fascicularis_5.0.102.gtf.gz",
                           isoformNtFasta = "./source_data/isoformswitchanalyzer/reference/Macaca_fascicularis_0.5.rna.fa.gz",
                           showProgress = TRUE)

#summary(aSwitchList)
#head(aSwitchList)

#subset_SwitchList <- subsetSwitchAnalyzeRlist(switchAnalyzeRlist = aSwitchList,
#                                              subset = abs(aSwitchList$isoformFeatures$dIF) > 0.1)
#summary(subset_SwitchList)


First_SwitchList <- isoformSwitchAnalysisPart1(switchAnalyzeRlist   = aSwitchList,
                                               alpha = 0.05, #default
                                               dIFcutoff = 0.1, #default
                                               switchTestMethod = 'DEXSeq', #default
                                               genomeObject = BSgenome.Mfascicularis.NCBI.5.0,
                                               # pathToOutput = 'path/to/where/output/should/be/'
                                               overwriteORF = FALSE, #default
                                               outputSequences      = TRUE, # change to TRUE whan analyzing your own data 
                                               prepareForWebServers = FALSE,
                                               quiet = FALSE #default
                                               )

#extractSwitchSummary(First_SwitchList)

Second_SwitchList <- isoformSwitchAnalysisPart2(switchAnalyzeRlist        = First_SwitchList,
                                                codingCutoff              = 0.5,    # since we are using CPC2
                                                removeNoncodinORFs        = TRUE,  # Because ORF was predicted de novo
                                                pathToCPC2resultFile      = "./source_data/isoformswitchanalyzer/extdata/CPC2/CPC2.txt",
                                                pathToPFAMresultFile      = "./source_data/isoformswitchanalyzer/extdata/Pfam/Pfam.txt",
                                                pathToIUPred2AresultFile  = "./source_data/isoformswitchanalyzer/extdata/IUPred2A/IUPred2A.txt",
                                                pathToSignalPresultFile   = "./source_data/isoformswitchanalyzer/extdata/signalP/output_protein_type.txt",
                                                outputPlots               = FALSE  # keeps the function from outputting the plots from this example
                                                )

##################
## result_top10 ##
##################

switchPlotTopSwitches(
  switchAnalyzeRlist = Second_SwitchList, 
  n = 10,                                             # Set to Inf for all
  filterForConsequences = TRUE,
  fileType = "pdf",                                   # alternative is "png"
  pathToOutput = "./source_data/isoformswitchanalyzer/result_top10/"
)


#extractSwitchSummary(Second_SwitchList, filterForConsequences = TRUE)

#head(Second_SwitchList)
#dim(Second_SwitchList)

subset_secondswitchanalyzed <- subsetSwitchAnalyzeRlist(
  Second_SwitchList,
  Second_SwitchList$isoformFeatures$condition_1 == 'G1' & Second_SwitchList$isoformFeatures$condition_2 == 'G2' | 
    Second_SwitchList$isoformFeatures$condition_1 == 'G2' & Second_SwitchList$isoformFeatures$condition_2 == 'G3' | 
    Second_SwitchList$isoformFeatures$condition_1 == 'G3' & Second_SwitchList$isoformFeatures$condition_2 == 'G4')


#head(subset_secondswitchanalyzed)
#dim(subset_secondswitchanalyzed)

#head(subset_secondswitchanalyzed$isoformCountMatrix)

################
## TRANSCRIPT ##
################

png("C./source_data/isoformswitchanalyzer/figures/TSW_transcript.png",width=8,height=1,units="in",res=1500)
switchPlotTranscript(subset_secondswitchanalyzed, gene = 'CTSW',
                     localTheme = theme_bw() + theme(panel.border = element_blank(), panel.grid.major = element_blank(),panel.grid.minor = element_blank(), axis.line = element_line(colour = "black")))
dev.off()


##############
##result_all##
##############

G1G2 <- read.table("G1_G2_totalDTU_gene.txt",sep="\t",header = FALSE)
G2G3 <- read.table("G2_G3_totalDTU_gene.txt",sep="\t",header = FALSE)
G3G4 <- read.table("G3_G4_totalDTU_gene.txt",sep="\t",header = FALSE)


for (i in G1G2$V1){
  png(filename = paste('./source_data/isoformswitchanalyzer/result_all/',i,'_G1G2.png',sep=''),width = 1500, height = 500)
  switchPlot(Second_SwitchList,
             gene = i,
             condition1 = 'G1',
             condition2 = 'G2',
             localTheme = theme_bw(base_size = 13))
  dev.off()
}

for (i in G2G3$V1){
  png(filename = paste('./source_data/isoformswitchanalyzer/result_all/',i,'_G2G3.png',sep=''),width = 1500, height = 500)
  switchPlot(Second_SwitchList,
             gene = i,
             condition1 = 'G2',
             condition2 = 'G3',
             localTheme = theme_bw(base_size = 13))
  dev.off()
}

for (i in G3G4$V1){
  png(filename = paste('./source_data/isoformswitchanalyzer/result_all/',i,'_G3G4.png',sep=''),width = 1500, height = 500)
  switchPlot(Second_SwitchList,
             gene = i,
             condition1 = 'G3',
             condition2 = 'G4',
             localTheme = theme_bw(base_size = 13))
  dev.off()
}

###################
## domain_result ##
###################

png("./source_data/isoformswitchanalyzer/figures/domain_result.png",width=9,height=4,units="in",res=1200)
extractConsequenceSummary(subset_secondswitchanalyzed,
                          consequencesToAnalyze='all',
                          returnResult = FALSE,
                          plotGenes = FALSE,           # enables analysis of genes (instead of isoforms)
                          asFractionTotal = FALSE,      # enables analysis of fraction of significant features
                          localTheme =  theme_bw()+theme(axis.text.x.bottom = element_text(angle=280,size=10))
)
dev.off()


#######################
## isoformswitch_sig ##
#######################

vol_G1_G2 <- subset(Second_SwitchList$isoformFeatures ,condition_1 == 'G1' & condition_2 == 'G2')
vol_G1_G2 <- select(vol_G1_G2,'isoform_id','gene_id','gene_name','condition_1','condition_2','isoform_switch_q_value','dIF','IF1','IF2')

vol_G2_G3 <- subset(Second_SwitchList$isoformFeatures ,condition_1 == 'G2' & condition_2 == 'G3')
vol_G2_G3 <- select(vol_G2_G3,'isoform_id','gene_id','gene_name','condition_1','condition_2','isoform_switch_q_value','dIF','IF1','IF2')

vol_G3_G4 <- subset(Second_SwitchList$isoformFeatures ,condition_1 == 'G3' & condition_2 == 'G4')
vol_G3_G4 <- select(vol_G3_G4,'isoform_id','gene_id','gene_name','condition_1','condition_2','isoform_switch_q_value','dIF','IF1','IF2')


write.table(vol_G1_G2, file='./source_data/isoformswitchanalyzer/G1_G2_isoformswitchlist_sig.txt', sep= "\t", col.names = FALSE, row.names = FALSE)
write.table(vol_G2_G3, file='./source_data/isoformswitchanalyzer/G2_G3_isoformswitchlist_sig.txt', sep= "\t", col.names = FALSE, row.names = FALSE)
write.table(vol_G3_G4, file='./source_data/isoformswitchanalyzer/G3_G4_isoformswitchlist_sig.txt', sep= "\t", col.names = FALSE, row.names = FALSE)

G1_G2_gene = vol_G1_G2[-which(duplicated(vol_G1_G2$gene_name)),]
G1_G2_gene = na.omit(G1_G2_gene)
G2_G3_gene = vol_G2_G3[-which(duplicated(vol_G2_G3$gene_name)),]
G2_G3_gene = na.omit(G1_G2_gene)
G3_G4_gene = vol_G3_G4[-which(duplicated(vol_G3_G4$gene_name)),]
G3_G4_gene = na.omit(G3_G4_gene)
G1_G4_gene = vol_G1_G4[-which(duplicated(vol_G1_G4$gene_name)),]
G1_G4_gene = na.omit(G1_G4_gene)


write.table(G1_G2_gene$gene_name, file='./source_data/isoformswitchanalyzer/G1_G2_totalDTU_gene.txt', sep= "\t", col.names = FALSE, row.names = FALSE)
write.table(G2_G3_gene$gene_name, file='./source_data/isoformswitchanalyzer/G2_G3_totalDTU_gene.txt', sep= "\t", col.names = FALSE, row.names = FALSE)
write.table(G3_G4_gene$gene_name, file='./source_data/isoformswitchanalyzer/G3_G4_totalDTU_gene.txt', sep= "\t", col.names = FALSE, row.names = FALSE)


#######################################
#######     Volcano Plot    ###########
#######################################
vol <- vol_G1_G2
vol <- na.omit(vol)

#rownames(vol) <- vol$gisoform
head(vol)

library(EnhancedVolcano)


keyvals <- ifelse(vol$isoform_switch_q_value < 0.05 & as.numeric(vol$dIF) < -0.1, 'skyblue',
                  ifelse(vol$isoform_switch_q_value < 0.05 & as.numeric(vol$dIF) > 0.1, 'pink','grey'))

keyvals[is.na(keyvals)] <- 'grey'
names(keyvals)[keyvals == 'pink'] <- 'UP'
names(keyvals)[keyvals == 'grey'] <- 'Not sig'
names(keyvals)[keyvals == 'skyblue'] <- 'DOWN'


png("./source_data/isoformswitchanalyzer/figures/G1-G2_isoform_volcanoplot.png")
EnhancedVolcano(vol,lab=vol$gene_name,
                x='dIF',
                y='isoform_switch_q_value',
                selectLab = vol$gene_name[which(names(keyvals) %in% c('UP', 'DOWN'))],
                xlab = bquote(dIF),
                xlim = c(-0.8,0.8),
                ylim = c(0,52),
                pCutoff = 0.05,
                FCcutoff = 0.1,
                pointSize = 2.0,
                labSize = 3.5,
                colCustom = keyvals,
                colAlpha = 0.5,
                legendPosition = 'bottom',
                legendLabSize = 15,
                legendIconSize = 5.0,
                gridlines.major = FALSE,
                gridlines.minor = FALSE,
                border = 'partial',
                borderWidth = 0.5,
                drawConnectors=FALSE,
                borderColour = 'black',
                title='G3-G4',
                subtitle='')
dev.off()



#############################################
#####  Predicting Alternative Splicing  #####
#############################################


png("./source_data/isoformswitchanalyzer/figures/alternative_splicing.png",width=5,height=4,units="in",res=1000)
extractSplicingSummary(subset_secondswitchanalyzed,
                       asFractionTotal = FALSE,
                       plotGenes=FALSE,
                       localTheme =  theme_bw()+theme(axis.text.x.bottom = element_text(angle=280,size=10)))
dev.off()
